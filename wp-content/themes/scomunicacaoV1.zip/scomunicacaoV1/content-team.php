<!-- Features Nossa Equipe Start -->
<section id="nossa-equipe" class="section" data-stellar-background-ratio="0.2">
    <br><br>
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Nossa Equipe</h2>
            <hr class="lines">
            <p class="section-subtitle wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s">
            </p>
        </div>

        <div class="row">


            <div class="col-md-4 col-xs-12 box-item">
                <div class="text">
                    <h4>Douglas Luan</h4><br>
                    <p>Jornalista formado pela Universidade Santa Cecília (Santos-SP), pós-graduado em Marketing pela
                        Faculdade Metropolitanas Unidas (FMU) e
                        especializado em Marketing Político e Eleitoral pela PUC-SP. Já trabalhou
                        nas prefeituras de Santos e São Vicente; no Governo de São Paulo e na

                        Câmara dos Deputados. Também atuou em jornais e rádios da Baixada
                        Santista, foi freelancer do Jornal Estado de S. Paulo e participou de projetos
                        do canal Esporte Interativo.</p>
                </div>
            </div>

            <div class="col-md-2 col-xs-12 box-item">
                <img src="<?php bloginfo('template_url'); ?>/img/features/dlA.png" alt="Foto Douglas Luan"></div>


            <div class="col-md-4 col-xs-12 box-item">

                <div class="text">
                    <h4>Sheila Almeida</h4>
                    <h5 class="colab">(Colaboradora)</h5>

                    <p>Jornalista formada pela Universidade Santa Cecília (Santos-SP) e pós-graduada em Gestão em
                        Comunicação Estratégica e Marketing pela mesma
                        instituição. É repórter do Jornal A Tribuna de Santos desde 2011, já
                        produziu reportagens para diversas editorias e viajou a vários estados do
                        Brasil para coberturas especiais. Também trabalhou em revistas, emissoras
                        de rádio da Baixada Santista, na Secretaria de Comunicação da Prefeitura
                        de Santos e em assessorias empresariais.</p>
                </div>
            </div>
            <div class="col-md-2 col-xs-12 box-item-she"><img
                    src="<?php bloginfo('template_url'); ?>/img/features/sheB.png" alt="Foto Sheila Almeida"></div>

        </div>
</section>
<!-- Features Section End -->