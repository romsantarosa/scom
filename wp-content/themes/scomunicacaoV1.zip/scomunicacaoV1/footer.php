  <!-- Footer Section Start -->
  <footer>
      <div class="container text-center">
          
                  <ul class="footer-links">
                      <li>
                          <a href="#home">HOME</a>
                      </li>

                      <li>
                          <a href="#services">QUEM SOMOS</a>
                      </li>

                      <li>
                          <a href="#team">NOSSA EQUIPE</a>
                      </li>

                      <li>
                          <a href="#solutions">NOSSAS SOLUÇÕES</a>
                      </li>

                      <li>
                          <a href="#features">MKT POLÍTICO FÁCIL</a>
                      </li>

                      <li>
                          <a href="#">CASES</a>
                      </li>

                      <li>
                          <a href="#">BLOG</a>
                      </li>

                      <li>
                          <a href="#contact">CONTATO</a>
                      </li>

                  </ul>
              </div>
        
            <div class="container text-center">
                  <div class="copyright">
                      <p><?php bloginfo('name'); ?> - Todos os direitos reservados. &copy; <?php echo Date('Y'); ?></p>
                      <p>Designed & Developed by <a rel="nofollow" href="https://uideck.com">Rom Santa Rosa</a></p>
                  </div>

          </div>

  </footer>


  <!-- Footer Section End -->

  <!-- Go To Top Link -->
  <a href="#" class="back-to-top">
      <i class="lnr lnr-arrow-up"></i>
  </a>

  <!-- jQuery first, then Tether, then Bootstrap JS. -->
  <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.9"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/core.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery-min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/popper.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.mixitup.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/nivo-lightbox.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/owl.carousel.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.stellar.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.nav.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/scrolling-nav.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.easing.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/smoothscroll.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.slicknav.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/wow.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.vide.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.counterup.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/jquery.magnific-popup.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/waypoints.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/form-validator.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/contact-form-script.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/main.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/style.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/typewriter.js"></script>


  </body>

  </html>