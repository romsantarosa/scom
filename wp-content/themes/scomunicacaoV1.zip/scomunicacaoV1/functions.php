<?php

register_nav_menus(
    array(
        'meu_menu_principal' => 'Menu Principal'
    )
);

?>