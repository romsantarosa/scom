<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <!-- Required meta tags -->
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords"
        content="Comunicação Integrada, Comunicação, Marketing, Político, Mídias, Mídia Digital, Consultoria, Assessoria, Gestão, Planejamento, Estratégia">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="author" content="Rom Santa Rosa">
    <title><?php bloginfo('name'); ?></title>

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Julius+Sans+One|Montserrat|Staatliches" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/img/fav.ico" />
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/line-icons.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.carousel.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.theme.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/nivo-lightbox.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/magnific-popup.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/slicknav.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/animate.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/responsive.css">
    <!--<?php wp_head(); ?>-->
</head>

<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg fixed-top scrolling-navbar indigo">
  <div class="container">
    <div class="navbar-header">
       
      <div class="collapse navbar-collapse" id="main-navbar">
        <ul class="navbar-nav mr-auto w-100 justify-content-left">
          <li class="nav-item">
            <a class="nav-link page-scroll"><?php wp_nav_menu(array('theme_location' => 'meu_menu_principal')); ?></a></li>
              <form class="busca" action="">
                <div class="blocoicons">
                  <input type="text" placeholder="Pesquisar...">
                    <button><img src="<?php bloginfo('template_url'); ?>/img/lupa-b.png"></button>
                </div>
              </form>
        </ul>
      </div>
    </div>
  </div>


    <ul class="mobile-menu">
      <li class="page-scroll">
            <a class="nav-link page-scroll"><?php wp_nav_menu(array('theme_location' => 'meu_menu_principal')); ?></a></li>
              <form class="busca" action="">
                <div class="blocoicons">
                  <input type="text" placeholder="Pesquisar...">
                  <button><img src="<?php bloginfo('template_url'); ?>/img/lupa.png"></button>
                </div>
              </form>
    </ul>

</nav>
<!-- Navbar End -->
<!-- Header Section End -->