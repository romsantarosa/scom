<?php get_header(); ?>

<section class="container">

        <div class="col-sm-10">
            <?php 
                if(have_posts()) :
                while (have_posts()) : the_post(); 
            ?>
         <h1><?php the_title(); ?></h1>
         <p>Publicado em <?php echo get_the_date(); ?> por <?php the_author(); ?></p>
         <p>Categorias: <?php the_category(' '); ?></p>
         <p><?php the_tags('Tags: ', ', '); ?></p>
         <p><?php the_content(); ?></p>
            <?php 
            endwhile;
            ?>
            <?php 
              else: 
            ?>
            <p>--- Não há conteúdo para mostrar! ---</p>
            <?php 
          endif;          
            ?>
</section>


<?php get_footer(); ?>