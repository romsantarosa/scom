<?php get_header(); ?>


<section class="container">

        <div class="col-sm-10">
            <?php 
                if(have_posts()) :
                while (have_posts()) : the_post(); 
            ?>
            <?php get_template_part('content', get_post_format()); ?>
            <?php 
            endwhile;
            ?>
            <?php 
              else: 
            ?>
            <p>--- Não há conteúdo para mostrar! ---</p>
            <?php 
          endif;          
            ?>
</section>

<?php get_footer(); ?>